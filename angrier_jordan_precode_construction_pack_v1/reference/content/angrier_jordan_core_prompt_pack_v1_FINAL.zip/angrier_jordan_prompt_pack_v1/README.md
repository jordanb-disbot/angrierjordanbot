# Angrier Jordan Core Prompt Pack v1

Codex-ready structured content for the four core party-game prompt banks.

## Counts
- WYR continuation: 1,540 entries, WYR-0461 through WYR-2000
- Truth: 1,500
- Dare: 1,200
- What Would You Do: 1,500
- Previously approved WYR: WYR-0001 through WYR-0460

After combining the existing approved WYR set with this continuation, the core library target is 6,200 prompts.

## Categories
Casual, Friends, Dating, Married, Spicy, Unhinged.
`Random` is a runtime selector over enabled categories, not a separate bank.

## Approval-by-exception
The 25 held-back privacy/intensity prompts were omitted and replaced with safe alternatives. All content in this final pack is enabled and ready for import.

## Suggested DB fields
id, game, category, intensity, text/scenario, option_a, option_b, options, tags, enabled, review_status, content_version, use_count, last_used_at.

## Runtime repetition protection
- Exclude roughly the last 250 used IDs for the selected game.
- Exclude roughly the last 75–100 used IDs in the selected category.
- Never repeat within the same active session.
- Skip must force a different prompt ID.
- Weight underused eligible prompts upward.

## Codex
Seed these files into PostgreSQL and keep prompt content separate from application code so future content packs can be imported without changing the game engine.
